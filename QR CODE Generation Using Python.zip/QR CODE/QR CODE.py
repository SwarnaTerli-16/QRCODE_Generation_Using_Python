import qrcode

data = 'https://swarna-terli-portfolio.netlify.app/'
qr = qrcode.QRCode(
    version = 5,
    box_size = 5,
    border  = 2,
)

qr.add_data(data)
qr.make(fit=True)

img = qr.make_image(fill_color='white',back_color='black')
img.save('E:/MYWORK/PROJECTS/QR CODE/portfolioqrcode.png')
img.show()



